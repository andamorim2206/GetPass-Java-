package com.example.getpass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetpassApplicationTests {

	@Test
	void contextLoads() {
	}

}
